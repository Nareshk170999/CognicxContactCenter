--exec usp_OutboundCalls_Manage

--drop procedure usp_OutboundCall_Manage
CREATE   PROCEDURE [dbo].[usp_OutboundCalls_Manage]
    @action VARCHAR(10),
	@SLNO INT = NULL,
    @TenantID INT = NULL,
    @CustID INT = NULL,
    @SequenceID INT = NULL,
    @ContactType INT = NULL,
    @ContactTypeName VARCHAR(255) = NULL,
    @ContactSubType INT = NULL,
    @SiteID INT = NULL,
    @SiteName VARCHAR(255) = NULL,
    @SkillsetID INT = NULL,
    @SkillsetName VARCHAR(255) = NULL,
    @AgentSurName VARCHAR(255) = NULL,
    @AgentGivenName VARCHAR(255) = NULL,
    @SupervisorSurName VARCHAR(255) = NULL,
    @SupervisorGivenName VARCHAR(255) = NULL,
    @AgentID INT = NULL,
    @SupervisorID INT = NULL,
    @OriginatedStamp DATETIME = NULL,
    @InitialDisposition VARCHAR(255) = NULL,
    @HandlingTime INT = NULL,
    @ConsultTime INT = NULL,
    @HoldTime INT = NULL,
    @WaitTime INT = NULL,
    @NumberOfTimesOnHold INT = NULL,
    @QAScore INT = NULL
    
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @statusCode INT, @errorCode INT, @errorMsg NVARCHAR(MAX);

    IF @action = 'INSERT'
    BEGIN
        BEGIN TRY
            -- Check if the record with the specified AgentID already exists
            IF NOT EXISTS (SELECT 1 FROM OutboundCalls WHERE SLNO = @SLNO)
            BEGIN
                INSERT INTO OutboundCalls (
                    TenantID, CustID, SequenceID, ContactType, ContactTypeName,
                    ContactSubType, SiteID, SiteName, SkillsetID, SkillsetName,
                    AgentSurName, AgentGivenName, SupervisorSurName, SupervisorGivenName,
                    AgentID, SupervisorID, OriginatedStamp, InitialDisposition,
                    HandlingTime, ConsultTime, HoldTime, WaitTime,
                    NumberOfTimesOnHold, QAScore
                )
                VALUES (
                    @TenantID, @CustID, @SequenceID, @ContactType, @ContactTypeName,
                    @ContactSubType, @SiteID, @SiteName, @SkillsetID, @SkillsetName,
                    @AgentSurName, @AgentGivenName, @SupervisorSurName, @SupervisorGivenName,
                    @AgentID, @SupervisorID, @OriginatedStamp, @InitialDisposition,
                    @HandlingTime, @ConsultTime, @HoldTime, @WaitTime,
                    @NumberOfTimesOnHold, @QAScore
                );

                SET @statusCode = 1;
                SET @errorCode = NULL;
                SET @errorMsg = NULL;
            END
            ELSE
            BEGIN
                -- Record with the specified AgentID already exists
                SET @statusCode = 0;
                SET @errorCode = 1001; -- You can choose any custom error code
                SET @errorMsg = 'Record with the specified AgentID already exists';
            END
        END TRY
        BEGIN CATCH
            SET @statusCode = 0;
            SET @errorCode = ERROR_NUMBER();
            SET @errorMsg = ERROR_MESSAGE();
        END CATCH
    END
    ELSE IF @action = 'UPDATE'
    BEGIN
        BEGIN TRY
            IF EXISTS (SELECT 1 FROM OutboundCalls WHERE SLNO = @SLNO)
            BEGIN
                UPDATE OutboundCalls
                SET
                    TenantID = @TenantID,
                    CustID = @CustID,
                    SequenceID = @SequenceID,
                    ContactType = @ContactType,
                    ContactTypeName = @ContactTypeName,
                    ContactSubType = @ContactSubType,
                    SiteID = @SiteID,
                    SiteName = @SiteName,
                    SkillsetID = @SkillsetID,
                    SkillsetName = @SkillsetName,
                    AgentSurName = @AgentSurName,
                    AgentGivenName = @AgentGivenName,
                    SupervisorSurName = @SupervisorSurName,
                    SupervisorGivenName = @SupervisorGivenName,
                    SupervisorID = @SupervisorID,
                    OriginatedStamp = @OriginatedStamp,
                    InitialDisposition = @InitialDisposition,
                    HandlingTime = @HandlingTime,
                    ConsultTime = @ConsultTime,
                    HoldTime = @HoldTime,
                    WaitTime = @WaitTime,
                    NumberOfTimesOnHold = @NumberOfTimesOnHold,
                    QAScore = @QAScore
                    --SLNO = @SLNO
                WHERE SLNO = @SLNO;

                SET @statusCode = 1;
                SET @errorCode = NULL;
                SET @errorMsg = NULL;
            END
            ELSE
            BEGIN
                -- Record with the specified AgentID does not exist
                SET @statusCode = 0;
                SET @errorCode = 1002; -- You can choose any custom error code
                SET @errorMsg = 'Record not found for the given AgentID';
            END
        END TRY
        BEGIN CATCH
            SET @statusCode = 0;
            SET @errorCode = ERROR_NUMBER();
            SET @errorMsg = ERROR_MESSAGE();
        END CATCH

	END
	ELSE IF @action = 'FETCHALL'
    BEGIN
        -- Fetch all records
        SELECT 
           TenantID, CustID, SequenceID, ContactType, ContactTypeName,
                    ContactSubType, SiteID, SiteName, SkillsetID, SkillsetName,
                    AgentSurName, AgentGivenName, SupervisorSurName, SupervisorGivenName,
                    AgentID, SupervisorID, OriginatedStamp, InitialDisposition,
                    HandlingTime, ConsultTime, HoldTime, WaitTime,
                    NumberOfTimesOnHold, QAScore
        FROM OutboundCalls;
        RETURN;
    END
    ELSE IF @action = 'DELETE'
    BEGIN
      
             IF EXISTS (SELECT 1 FROM OutboundCalls WHERE SLNO = @SLNO)
			 BEGIN
			   BEGIN TRY
            DELETE FROM OutboundCalls WHERE SLNO = @SLNO;

            SET @statusCode = 1;
            SET @errorCode = NULL;
            SET @errorMsg = NULL;
        END TRY
        BEGIN CATCH
            SET @statusCode = 0;
            SET @errorCode = ERROR_NUMBER();
            SET @errorMsg = ERROR_MESSAGE();
        END CATCH
    END
	 ELSE
        BEGIN
            -- Record with the specified id does not exist
            SET @statusCode = 0;
            SET @errorCode = 999; -- You can choose any custom error code
            SET @errorMsg = 'Record not found for the given id';
        END
		END


    -- Return response
    SELECT @statusCode AS statusCode, @errorCode AS errorCode, @errorMsg AS errorMsg;
END;
go

