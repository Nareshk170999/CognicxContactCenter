
--drop procedure usp_AgentActivityDetails_Manage
CREATE    PROCEDURE [dbo].[usp_AgentActivityDetails_Manage]
    @action VARCHAR(10), 
	@SLNO INT = NULL,
    @TenantID INT = NULL,
    @Timestamp DATETIME = NULL,
	@AgentID INT = NULL,
    @AgentSurName VARCHAR(255) = NULL,
    @AgentGivenName VARCHAR(255) = NULL,
    @SupervisorLogin INT = NULL,
    @SupervisorSurName VARCHAR(255) = NULL,
    @SupervisorGivenName VARCHAR(255) = NULL,
    @BreakTime INT = NULL,
    @CallsAnswered INT = NULL,
    @CallsOffered INT = NULL,
    @HoldTime INT = NULL,
    @LoggedInTime INT = NULL,
    @NotReadyTime INT = NULL,
    @RingTime INT = NULL,
    @ShortCallsAnswered INT = NULL,
    @TalkTime INT = NULL,
    @WaitingTime INT = NULL,
    @UserID [varchar](255) = NULL,
    @SupervisorUserID [varchar](255) = NULL,
    @Time [datetime] = NULL,
    @SiteID INT = NULL,
    @Site VARCHAR(255) = NULL,
    @PostCallProcessingTime INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @statusCode INT, @errorCode INT, @errorMsg NVARCHAR(MAX), @insertedId INT;

    IF @action = 'INSERT'
    BEGIN
        BEGIN TRY
           IF NOT EXISTS (SELECT 1 FROM AgentActivityDetails WHERE SLNO = @SLNO)
		   BEGIN
            INSERT INTO AgentActivityDetails (
                TenantID,  Timestamp,AgentID, AgentSurName, AgentGivenName,
                SupervisorLogin, SupervisorSurName, SupervisorGivenName,
                BreakTime, CallsAnswered, CallsOffered,
                HoldTime, LoggedInTime, NotReadyTime, RingTime,
                ShortCallsAnswered, TalkTime, WaitingTime,
                UserID, SupervisorUserID, Time, SiteID, Site,
                PostCallProcessingTime
            )
            VALUES (
                @TenantID,  @Timestamp,@AgentID, @AgentSurName, @AgentGivenName,
                @SupervisorLogin, @SupervisorSurName, @SupervisorGivenName,
                @BreakTime, @CallsAnswered, @CallsOffered,
                @HoldTime, @LoggedInTime, @NotReadyTime, @RingTime,
                @ShortCallsAnswered, @TalkTime, @WaitingTime,
                @UserID, @SupervisorUserID, @Time, @SiteID, @Site,
                @PostCallProcessingTime
            );

			  SET @insertedId = SCOPE_IDENTITY();

            SET @statusCode = 1;
            SET @errorCode = NULL;
            SET @errorMsg = NULL;
			END
			ELSE
            BEGIN
                -- Record with the specified id already exists
                SET @statusCode = 0;
                SET @errorCode = 1001; -- You can choose any custom error code
                SET @errorMsg = 'Record with the specified id already exists';
                SET @insertedId = NULL;
            END
        END TRY
        BEGIN CATCH
            SET @statusCode = 0;
            SET @errorCode = ERROR_NUMBER();
            SET @errorMsg = ERROR_MESSAGE();
        END CATCH
    END
    ELSE IF @action = 'UPDATE'
    BEGIN
        BEGIN TRY
        IF EXISTS (SELECT 1 FROM AgentActivityDetails WHERE SLNO = @SLNO)
		BEGIN
            UPDATE AgentActivityDetails
            SET
			     TenantID=@TenantID,
                Timestamp = @Timestamp, 
				AgentID=@AgentID, 
				AgentSurName=@AgentSurName,
				AgentGivenName=@AgentGivenName,
                SupervisorLogin=@SupervisorLogin,
				SupervisorSurName=@SupervisorSurName,
				SupervisorGivenName=@SupervisorGivenName,
                BreakTime=@BreakTime,
				CallsAnswered=@CallsAnswered,
				CallsOffered=@CallsOffered,
                HoldTime=@HoldTime,
				LoggedInTime=@LoggedInTime,
				NotReadyTime=@NotReadyTime,
				RingTime=@RingTime,
                ShortCallsAnswered=@ShortCallsAnswered,
				TalkTime=@TalkTime,
				WaitingTime=@WaitingTime,
                UserID=@UserID,
				SupervisorUserID=@SupervisorUserID,
				Time=@Time,
				SiteID=@SiteID,           
				Site=@Site,
                PostCallProcessingTime=@PostCallProcessingTime
             
            WHERE SLNO = @SLNO;

            SET @statusCode = 1;
            SET @errorCode = NULL;
            SET @errorMsg = NULL;
			END
			 ELSE
            BEGIN
                -- Record with the specified id does not exist
                SET @statusCode = 0;
                SET @errorCode = 1002; -- You can choose any custom error code
                SET @errorMsg = 'Record not found for the given id';
            END
        END TRY
        BEGIN CATCH
            SET @statusCode = 0;
            SET @errorCode = ERROR_NUMBER();
            SET @errorMsg = ERROR_MESSAGE();
        END CATCH
    END
	ELSE IF @action = 'FETCHALL'
    BEGIN
        -- Fetch all records
        SELECT 
            SLNO,TenantID,  Timestamp,AgentID, AgentSurName, AgentGivenName,
            SupervisorLogin, SupervisorSurName, SupervisorGivenName,
            BreakTime, CallsAnswered, CallsOffered,
            HoldTime, LoggedInTime, NotReadyTime, RingTime,
            ShortCallsAnswered, TalkTime, WaitingTime,
            UserID, SupervisorUserID, Time, SiteID, Site,
            PostCallProcessingTime
        FROM AgentActivityDetails;
        RETURN;
    END
    ELSE IF @action = 'DELETE'
    BEGIN
      
             IF EXISTS (SELECT 1 FROM AgentActivityDetails WHERE SLNO = @SLNO)
			 BEGIN
			   BEGIN TRY
            DELETE FROM AgentActivityDetails WHERE SLNO = @SLNO;

            SET @statusCode = 1;
            SET @errorCode = NULL;
            SET @errorMsg = NULL;
        END TRY
        BEGIN CATCH
            SET @statusCode = 0;
            SET @errorCode = ERROR_NUMBER();
            SET @errorMsg = ERROR_MESSAGE();
        END CATCH
    END
	 ELSE
        BEGIN
            -- Record with the specified id does not exist
            SET @statusCode = 0;
            SET @errorCode = 999; -- You can choose any custom error code
            SET @errorMsg = 'Record not found for the given id';
        END
		END

    -- Return response
    SELECT @statusCode AS statusCode, @errorCode AS errorCode, @errorMsg AS errorMsg, @insertedId AS insertedId;
END;
go

