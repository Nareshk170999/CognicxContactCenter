


--exec InsertDataIntoTempTable
---select * from AgentActivityDetails
---select * from iAgentPerformanceStat
-- Create a stored procedure
----exec InsertDataIntoTempTable @LastProcessedTimestamp=''
CREATE PROCEDURE [dbo].[InsertDataIntoTempTable]
@LastProcessedTimestamp DATETIME=NULL
AS
BEGIN


CREATE TABLE #TempAgentActivityDetails (
    [SLNO] [int],
    [TenantID] [int] NULL,
    [Timestamp] [datetime] null,
    [AgentID] [int] NULL,
    [AgentSurName] [varchar](255) NULL,
    [AgentGivenName] [varchar](255) NULL,
    [SupervisorLogin] [int] NULL,
    [SupervisorSurName] [varchar](255) NULL,
    [SupervisorGivenName] [varchar](255) NULL,
    [BreakTime] [int] NULL,
    [CallsAnswered] [int] NULL,
    [CallsOffered] [int] NULL,
    [HoldTime] [int] NULL,
    [LoggedInTime] [int] NULL,
    [NotReadyTime] [int] NULL,
    [RingTime] [int] NULL,
    [ShortCallsAnswered] [int] NULL,
    [TalkTime] [int] NULL,
    [WaitingTime] [int] NULL,
    [UserID] [varchar](255) NULL,
    [SupervisorUserID] [varchar](255) NULL,
    [Time] [datetime] NULL,
    [SiteID] [int] NULL,
    [Site] [varchar](255) NULL,
    [PostCallProcessingTime] [int] NULL
	 
);

    -- Insert data into the temporary table
    INSERT INTO #TempAgentActivityDetails (
	   
        [Timestamp],
        [AgentID],
        [AgentSurName],
        [AgentGivenName],
        [SupervisorLogin],
        [SupervisorSurName],
        [SupervisorGivenName],
        [BreakTime],
        [CallsAnswered],
        [CallsOffered],
        [HoldTime],
        [LoggedInTime],
        [NotReadyTime],
        [RingTime],
        [ShortCallsAnswered],
        [TalkTime],
        [WaitingTime],
        [UserID],
        [SupervisorUserID],
        [Time],
        [SiteID],
        [Site],
        [PostCallProcessingTime],
		 SLNO
		
    )
    SELECT 
        [Timestamp],
        [AgentLogin] as [AgentID],
        [AgentSurName],
        [AgentGivenName],
        [SupervisorLogin],
        [SupervisorSurName],
        [SupervisorGivenName],
        [BreakTime],
        [CallsAnswered],
        [CallsOffered],
        [HoldTime],
        [LoggedInTime],
        [NotReadyTime],
        [RingTime],
        [ShortCallsAnswered],
        [TalkTime],
        [WaitingTime],
        [UserID],
        [SupervisorUserID],
        [Time],
        [SiteID],
        [Site],
        [PostCallProcessingTime],
		SLNO
    FROM [staging2].[dbo].[iAgentPerformanceStat]
	
	insert into AgentActivityDetails(
	
        [Timestamp],
        [AgentID],
        [AgentSurName],
        [AgentGivenName],
        [SupervisorLogin],
        [SupervisorSurName],
        [SupervisorGivenName],
        [BreakTime],
        [CallsAnswered],
        [CallsOffered],
        [HoldTime],
        [LoggedInTime],
        [NotReadyTime],
        [RingTime],
        [ShortCallsAnswered],
        [TalkTime],
        [WaitingTime],
        [UserID],
        [SupervisorUserID],
        [Time],
        [SiteID],
        [Site],
        [PostCallProcessingTime],
		 SLNO
		
    )
	select

	 [Timestamp],
        [AgentID],
        [AgentSurName],
        [AgentGivenName],
        [SupervisorLogin],
        [SupervisorSurName],
        [SupervisorGivenName],
        [BreakTime],
        [CallsAnswered],
        [CallsOffered],
        [HoldTime],
        [LoggedInTime],
        [NotReadyTime],
        [RingTime],
        [ShortCallsAnswered],
        [TalkTime],
        [WaitingTime],
        [UserID],
        [SupervisorUserID],
        [Time],
        [SiteID],
        [Site],
        [PostCallProcessingTime],
		 SLNO
		
		FROM #TempAgentActivityDetails
	 WHERE
		--AD.[Timestamp] > @LastProcessedTimestamp
		( [Timestamp] > @LastProcessedTimestamp  OR @LastProcessedTimestamp IS NULL)
	order by slno
	--select * from #TempAgentActivityDetails 
	select * from AgentActivityDetails
	drop table #TempAgentActivityDetails
	
END;

--select * from AgentActivityDetails
go

