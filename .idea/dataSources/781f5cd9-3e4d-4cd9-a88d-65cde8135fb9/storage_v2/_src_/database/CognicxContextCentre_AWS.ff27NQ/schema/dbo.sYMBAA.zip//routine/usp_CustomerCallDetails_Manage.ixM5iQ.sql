


CREATE    PROCEDURE [dbo].[usp_CustomerCallDetails_Manage]
    @action VARCHAR(10), 
	@SLNO INT = NULL,
    @AgentID INT = NULL,
    @CustID INT = NULL,
    @SequenceID INT = NULL,
    @GUID VARCHAR(255) = NULL,
    @CCMID INT = NULL,
    @ContactType INT = NULL,
    @ContactTypeName VARCHAR(255) = NULL,
    @ContactSubType INT = NULL,
    @Priority VARCHAR(255) = NULL,
    @SiteID INT = NULL,
    @SiteName VARCHAR(255) = NULL,
    @ApplicationID VARCHAR(255) = NULL,
    @ApplicationName VARCHAR(255) = NULL,
    @LastTreatmentID INT = NULL,
    @Treatment VARCHAR(255) = NULL,
    @LastTreatmentStamp DATETIME = NULL,
    @LastTreatmentTime DATETIME = NULL,
    @SkillsetID INT = NULL,
    @SkillsetName VARCHAR(255) = NULL,
    @LocalUserID INT = NULL,
    @AgentSurName VARCHAR(255) = NULL,
    @AgentGivenName VARCHAR(255) = NULL,
    @SupervisorSurName VARCHAR(255) = NULL,
    @SupervisorGivenName VARCHAR(255) = NULL,
    @SupervisorID INT = NULL,
    @OriginatedStamp DATETIME = NULL,
    @InitialDisposition VARCHAR(255) = NULL,
    @AppAbandonDelay INT = NULL,
    @AppAcceptedDelay INT = NULL,
    @SksAbandonDelay INT = NULL,
    @SksAcceptedDelay INT = NULL,
    @HandlingTime INT = NULL,
    @ConsultTime INT = NULL,
    @HoldTime INT = NULL,
    @NumberOfTimesOnHold INT = NULL,
    @NumberOfTimesRTQ INT = NULL,
    @FinalDisposition VARCHAR(255) = NULL,
    @FinalDispositionStamp DATETIME = NULL,
    @PresentingTime INT = NULL,
    @WaitTime INT = NULL,
    @ContactOriginatedStamp DATETIME = NULL,
    @FinalDispositionInterval DATETIME = NULL,
    @ServiceInterval DATETIME = NULL,
    @OriginatedInterval DATETIME = NULL,
    @DisconnectSource VARCHAR(255) = NULL,
    @CallsConferenced INT = NULL,
    @CallsReturnToQ INT = NULL,
    @CallsReturnToQDueToTimeout INT = NULL,
    @IdleTime INT = NULL,
    @TenantID INT = NULL
	
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @statusCode INT, @errorCode INT, @errorMsg NVARCHAR(MAX), @insertedId INT;

    IF @action = 'INSERT'
    BEGIN
        BEGIN TRY
            -- Check if the record with the specified AgentID already exists
            IF NOT EXISTS (SELECT 1 FROM CustomerCallDetails WHERE SLNO = @SLNO)
            BEGIN
                -- Insert record
                INSERT INTO CustomerCallDetails (
                    AgentID, CustID, SequenceID, GUID, CCMID, ContactType, ContactTypeName,
                    ContactSubType, Priority, SiteID, SiteName, ApplicationID, ApplicationName,
                    LastTreatmentID, Treatment, LastTreatmentStamp, LastTreatmentTime, SkillsetID,
                    SkillsetName, LocalUserID, AgentSurName, AgentGivenName, SupervisorSurName,
                    SupervisorGivenName, SupervisorID, OriginatedStamp, InitialDisposition,
                    AppAbandonDelay, AppAcceptedDelay, SksAbandonDelay, SksAcceptedDelay, HandlingTime,
                    ConsultTime, HoldTime, NumberOfTimesOnHold, NumberOfTimesRTQ, FinalDisposition,
                    FinalDispositionStamp, PresentingTime, WaitTime, ContactOriginatedStamp,
                    FinalDispositionInterval, ServiceInterval, OriginatedInterval, DisconnectSource,
                    CallsConferenced, CallsReturnToQ, CallsReturnToQDueToTimeout, IdleTime, TenantID
                )
                VALUES (
                    @AgentID, @CustID, @SequenceID, @GUID, @CCMID, @ContactType, @ContactTypeName,
                    @ContactSubType, @Priority, @SiteID, @SiteName, @ApplicationID, @ApplicationName,
                    @LastTreatmentID, @Treatment, @LastTreatmentStamp, @LastTreatmentTime, @SkillsetID,
                    @SkillsetName, @LocalUserID, @AgentSurName, @AgentGivenName, @SupervisorSurName,
                    @SupervisorGivenName, @SupervisorID, @OriginatedStamp, @InitialDisposition,
                    @AppAbandonDelay, @AppAcceptedDelay, @SksAbandonDelay, @SksAcceptedDelay, @HandlingTime,
                    @ConsultTime, @HoldTime, @NumberOfTimesOnHold, @NumberOfTimesRTQ, @FinalDisposition,
                    @FinalDispositionStamp, @PresentingTime, @WaitTime, @ContactOriginatedStamp,
                    @FinalDispositionInterval, @ServiceInterval, @OriginatedInterval, @DisconnectSource,
                    @CallsConferenced, @CallsReturnToQ, @CallsReturnToQDueToTimeout, @IdleTime, @TenantID
                );

                -- Get the auto-incremented AgentID of the inserted record
                SET @insertedId = @SLNO;
		
                -- Successful insert
                SET @statusCode = 1;
                SET @errorCode = NULL;
                SET @errorMsg = NULL;
            END
            ELSE
            BEGIN
                -- Record with the specified AgentID already exists
                SET @statusCode = 0;
                SET @errorCode = 1001; -- You can choose any custom error code
                SET @errorMsg = 'Record with the specified AgentID already exists';
                SET @insertedId = NULL;
            END
        END TRY
        BEGIN CATCH
            -- Failed insert
            SET @statusCode = 0;
            SET @errorCode = ERROR_NUMBER();
            SET @errorMsg = ERROR_MESSAGE();
            SET @insertedId = NULL;
        END CATCH
    END
    ELSE IF @action = 'UPDATE'
    BEGIN
        BEGIN TRY
            -- Check if the record with the specified AgentID exists
            IF EXISTS (SELECT 1 FROM CustomerCallDetails WHERE SLNO = @SLNO)
            BEGIN
                -- Update record
                UPDATE CustomerCallDetails
                SET 
                    CustID = @CustID,
                    SequenceID = @SequenceID,
                    GUID = @GUID,
                    CCMID = @CCMID,
                    ContactType = @ContactType,
                    ContactTypeName = @ContactTypeName,
                    ContactSubType = @ContactSubType,
                    Priority = @Priority,
                    SiteID = @SiteID,
                    SiteName = @SiteName,
                    ApplicationID = @ApplicationID,
                    ApplicationName = @ApplicationName,
                    LastTreatmentID = @LastTreatmentID,
                    Treatment = @Treatment,
                    LastTreatmentStamp = @LastTreatmentStamp,
                    LastTreatmentTime = @LastTreatmentTime,
                    SkillsetID = @SkillsetID,
                    SkillsetName = @SkillsetName,
                    LocalUserID = @LocalUserID,
                    AgentSurName = @AgentSurName,
                    AgentGivenName = @AgentGivenName,
                    SupervisorSurName = @SupervisorSurName,
                    SupervisorGivenName = @SupervisorGivenName,
                    SupervisorID = @SupervisorID,
                    OriginatedStamp = @OriginatedStamp,
                    InitialDisposition = @InitialDisposition,
                    AppAbandonDelay = @AppAbandonDelay,
                    AppAcceptedDelay = @AppAcceptedDelay,
                    SksAbandonDelay = @SksAbandonDelay,
                    SksAcceptedDelay = @SksAcceptedDelay,
                    HandlingTime = @HandlingTime,
                    ConsultTime = @ConsultTime,
                    HoldTime = @HoldTime,
                    NumberOfTimesOnHold = @NumberOfTimesOnHold,
                    NumberOfTimesRTQ = @NumberOfTimesRTQ,
                    FinalDisposition = @FinalDisposition,
                    FinalDispositionStamp = @FinalDispositionStamp,
                    PresentingTime = @PresentingTime,
                    WaitTime = @WaitTime,
                    ContactOriginatedStamp = @ContactOriginatedStamp,
                    FinalDispositionInterval = @FinalDispositionInterval,
                    ServiceInterval = @ServiceInterval,
                    OriginatedInterval = @OriginatedInterval,
                    DisconnectSource = @DisconnectSource,
                    CallsConferenced = @CallsConferenced,
                    CallsReturnToQ = @CallsReturnToQ,
                    CallsReturnToQDueToTimeout = @CallsReturnToQDueToTimeout,
                    IdleTime = @IdleTime,
                    TenantID = @TenantID
                WHERE SLNO = @SLNO;

                -- Successful update
                SET @statusCode = 1;
                SET @errorCode = NULL;
                SET @errorMsg = NULL;
            END
            ELSE
            BEGIN
                -- Record with the specified AgentID does not exist
                SET @statusCode = 0;
                SET @errorCode = 1002; -- You can choose any custom error code
                SET @errorMsg = 'Record not found for the given AgentID';
            END
        END TRY
        BEGIN CATCH
            -- Failed update
            SET @statusCode = 0;
            SET @errorCode = ERROR_NUMBER();
            SET @errorMsg = ERROR_MESSAGE();
        END CATCH
    END
    ELSE IF @action = 'FETCHALL'
    BEGIN
        -- Fetch all records
        SELECT 
            AgentID, CustID, SequenceID, GUID, CCMID, ContactType, ContactTypeName,
            ContactSubType, Priority, SiteID, SiteName, ApplicationID, ApplicationName,
            LastTreatmentID, Treatment, LastTreatmentStamp, LastTreatmentTime, SkillsetID,
            SkillsetName, LocalUserID, AgentSurName, AgentGivenName, SupervisorSurName,
            SupervisorGivenName, SupervisorID, OriginatedStamp, InitialDisposition,
            AppAbandonDelay, AppAcceptedDelay, SksAbandonDelay, SksAcceptedDelay, HandlingTime,
            ConsultTime, HoldTime, NumberOfTimesOnHold, NumberOfTimesRTQ, FinalDisposition,
            FinalDispositionStamp, PresentingTime, WaitTime, ContactOriginatedStamp,
            FinalDispositionInterval, ServiceInterval, OriginatedInterval, DisconnectSource,
            CallsConferenced, CallsReturnToQ, CallsReturnToQDueToTimeout, IdleTime, TenantID
        FROM CustomerCallDetails;
        RETURN;
    END
    ELSE IF @action = 'DELETE'
    BEGIN
        -- Check if the record with the specified AgentID exists
        IF EXISTS (SELECT 1 FROM CustomerCallDetails WHERE SLNO = @SLNO)
        BEGIN
            BEGIN TRY
                -- Delete record based on AgentID
                DELETE FROM CustomerCallDetails WHERE SLNO = @SLNO;

                -- Successful delete
                SET @statusCode = 1;
                SET @errorCode = NULL;
                SET @errorMsg = NULL;
            END TRY
            BEGIN CATCH
                -- Failed delete
                SET @statusCode = 0;
                SET @errorCode = ERROR_NUMBER();
                SET @errorMsg = ERROR_MESSAGE();
            END CATCH
        END
        ELSE
        BEGIN
            -- Record with the specified AgentID does not exist
            SET @statusCode = 0;
            SET @errorCode = 999; -- You can choose any custom error code
            SET @errorMsg = 'Record not found for the given AgentID';
        END
    END

    -- Return response
    SELECT @statusCode AS statusCode, @errorCode AS errorCode, @errorMsg AS errorMsg, @insertedId AS insertedId;
END;
go

