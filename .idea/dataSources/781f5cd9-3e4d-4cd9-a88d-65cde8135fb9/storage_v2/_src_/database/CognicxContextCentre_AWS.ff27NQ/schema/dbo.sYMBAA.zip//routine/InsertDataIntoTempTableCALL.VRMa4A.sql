


---select * from customerCallDetails
---select * from iAgentPerformanceStat
-- Create a stored procedure

--exec InsertDataIntoTempTable1 @LastProcessedTimestamp='2023-04-04 18:04:48.000'
--exec InsertDataIntoTempTable1 @LastProcessedTimestamp=''


CREATE     PROCEDURE [dbo].[InsertDataIntoTempTableCALL]
@LastProcessedTimestamp DATETIME=NULL
AS
BEGIN

-- Create the temporary table
CREATE TABLE #TempCustomerDetails (
	[TenantID] [int] NULL,
	[CustID] [varchar](255) NULL,
	[SequenceID] [varchar](255) NULL,
	[GUID] [varchar](255) NULL,
	[CCMID] [varchar](255) NULL,
	[ContactType] [varchar](255) NULL,
	[ContactTypeName] [varchar](255) NULL,
	[ContactSubType] [varchar](255) NULL,
	[Priority] [varchar](255) NULL,
	[SiteID] [varchar](255) NULL,
	[SiteName] [varchar](255) NULL,
	[ApplicationID] [varchar](255) NULL,
	[ApplicationName] [varchar](255) NULL,
	[LastTreatmentID] [varchar](255) NULL,
	[Treatment] [varchar](255) NULL,
	[LastTreatmentStamp] [varchar](255) NULL,
	[LastTreatmentTime] [varchar](255) NULL,
	[SkillsetID] [varchar](255) NULL,
	[SkillsetName] [varchar](255) NULL,
	[LocalUserID] [varchar](255) NULL,
	[AgentSurName] [varchar](255) NULL,
	[AgentGivenName] [varchar](255) NULL,
	[SupervisorSurName] [varchar](255) NULL,
	[SupervisorGivenName] [varchar](255) NULL,
	[AgentID] [varchar](255) NULL,
	[SupervisorID] [varchar](255) NULL,
	[OriginatedStamp] [varchar](255) NULL,
	[InitialDisposition] [varchar](255) NULL,
	[AppAbandonDelay] [varchar](255) NULL,
	[AppAcceptedDelay] [varchar](255) NULL,
	[SksAbandonDelay] [varchar](255) NULL,
	[SksAcceptedDelay] [varchar](255) NULL,
	[HandlingTime] [varchar](255) NULL,
	[ConsultTime] [varchar](255) NULL,
	[HoldTime] [varchar](255) NULL,
	[NumberOfTimesOnHold] [varchar](255) NULL,
	[NumberOfTimesRTQ] [varchar](255) NULL,
	[FinalDisposition] [varchar](255) NULL,
	[FinalDispositionStamp] [varchar](255) NULL,
	[PresentingTime] [varchar](255) NULL,
	[WaitTime] [varchar](255) NULL,
	[ContactOriginatedStamp] [varchar](255) NULL,
	[FinalDispositionInterval] [varchar](255) NULL,
	[ServiceInterval] [varchar](255) NULL,
	[OriginatedInterval] [varchar](255) NULL,
	[DisconnectSource] [varchar](255) NULL,
	[CallsConferenced] [varchar](255) NULL,
	[CallsReturnToQ] [varchar](255) NULL,
	[CallsReturnToQDueToTimeout] [varchar](255) NULL,
	[IdleTime] [varchar](255) NULL
)


    -- Insert data into the temporary table
    INSERT INTO #TempCustomerDetails (

	   [TenantID]  ,    [CustID]  ,    [SequenceID] ,    [GUID] ,     [CCMID] ,    [ContactType] ,
    [ContactTypeName] ,    [ContactSubType] ,    [Priority] ,    [SiteID] ,    [SiteName] ,    [ApplicationID] ,
    [ApplicationName] ,    [LastTreatmentID] ,    [Treatment] ,    [LastTreatmentStamp],    [LastTreatmentTime] ,
    [SkillsetID] ,    [SkillsetName] ,    [LocalUserID] ,    [AgentSurName] ,    [AgentGivenName] ,
    [SupervisorSurName] ,    [SupervisorGivenName] ,    [AgentID] ,    [SupervisorID] ,    [OriginatedStamp] ,
    [InitialDisposition] ,    [AppAbandonDelay] ,    [AppAcceptedDelay] ,    [SksAbandonDelay] ,    [SksAcceptedDelay] ,
    [HandlingTime] ,    [ConsultTime] ,    [HoldTime] ,    [NumberOfTimesOnHold] ,    [NumberOfTimesRTQ] ,
    [FinalDisposition] ,    [FinalDispositionStamp] ,    [PresentingTime] ,    [WaitTime] ,    [ContactOriginatedStamp],
    [FinalDispositionInterval] ,    [ServiceInterval] ,    [OriginatedInterval] ,    [DisconnectSource],    [CallsConferenced],
    [CallsReturnToQ] ,    [CallsReturnToQDueToTimeout] ,    [IdleTime] 
	)

	SELECT

	
	    '2',    [CustID]  ,    [SequenceID] ,    [GUID] ,     [CCMID] ,    [ContactType] ,    [ContactTypeName] ,
    [ContactSubType] ,    [Priority] ,    [SiteID] ,    [SiteName] ,    [ApplicationID] ,    [ApplicationName] ,
    [LastTreatmentID] ,    [Treatment] ,    [LastTreatmentStamp],    [LastTreatmentTime] ,    [SkillsetID] ,
    [SkillsetName] ,    [LocalUserID] ,    [AgentSurName] ,    [AgentGivenName] ,    [SupervisorSurName] ,    [SupervisorGivenName] ,
    [AgentID] ,    [SupervisorID] ,    [OriginatedStamp] ,    [InitialDisposition] ,    [AppAbandonDelay] ,    [AppAcceptedDelay] ,
    [SksAbandonDelay] ,    [SksAcceptedDelay] ,    [HandlingTime] ,    [ConsultTime] ,    [HoldTime] ,    [NumberOfTimesOnHold] ,
    [NumberOfTimesRTQ] ,    [FinalDisposition] ,    [FinalDispositionStamp] ,    [PresentingTime] ,    [WaitTime] ,
    [ContactOriginatedStamp],    [FinalDispositionInterval] ,    [ServiceInterval] ,    [OriginatedInterval] ,    [DisconnectSource],
    '',   '' ,    '' ,    ''
FROM [staging2].[dbo].[eCSRStatall]

insert into customerCallDetails
(

	    [TenantID]  ,    [CustID]  ,    [SequenceID] ,    [GUID] ,     [CCMID] ,    [ContactType] ,    [ContactTypeName] ,
    [ContactSubType] ,    [Priority] ,    [SiteID] ,    [SiteName] ,    [ApplicationID] ,    [ApplicationName] ,    [LastTreatmentID] ,
    [Treatment] ,    [LastTreatmentStamp],    [LastTreatmentTime] ,    [SkillsetID] ,    [SkillsetName] ,    [LocalUserID] ,
    [AgentSurName] ,    [AgentGivenName] ,    [SupervisorSurName] ,    [SupervisorGivenName] ,    [AgentID] ,
    [SupervisorID] ,    [OriginatedStamp] ,    [InitialDisposition] ,    [AppAbandonDelay] ,    [AppAcceptedDelay] ,
    [SksAbandonDelay] ,    [SksAcceptedDelay] ,    [HandlingTime] ,    [ConsultTime] ,    [HoldTime] ,    [NumberOfTimesOnHold] ,
    [NumberOfTimesRTQ] ,    [FinalDisposition] ,    [FinalDispositionStamp] ,    [PresentingTime] ,    [WaitTime] ,
    [ContactOriginatedStamp],    [FinalDispositionInterval] ,    [ServiceInterval] ,    [OriginatedInterval] ,
    [DisconnectSource],    [CallsConferenced],    [CallsReturnToQ] ,    [CallsReturnToQDueToTimeout] ,    [IdleTime] 
	)
	select

	    [TenantID]  ,    [CustID]  ,    [SequenceID] ,    [GUID] ,     [CCMID] ,    [ContactType] ,    [ContactTypeName] ,
    [ContactSubType] ,    [Priority] ,    [SiteID] ,    [SiteName] ,    [ApplicationID] ,    [ApplicationName] ,
    [LastTreatmentID] ,    [Treatment] ,    [LastTreatmentStamp],    [LastTreatmentTime] ,    [SkillsetID] ,
    [SkillsetName] ,    [LocalUserID] ,    [AgentSurName] ,    [AgentGivenName] ,    [SupervisorSurName] ,
    [SupervisorGivenName] ,    [AgentID] ,    [SupervisorID] ,    [OriginatedStamp] ,    [InitialDisposition] ,
    [AppAbandonDelay] ,    [AppAcceptedDelay] ,    [SksAbandonDelay] ,    [SksAcceptedDelay] ,    [HandlingTime] ,
    [ConsultTime] ,    [HoldTime] ,    [NumberOfTimesOnHold] ,    [NumberOfTimesRTQ] ,    [FinalDisposition] ,
    [FinalDispositionStamp] ,    [PresentingTime] ,    [WaitTime] ,    [ContactOriginatedStamp],    [FinalDispositionInterval] ,
    [ServiceInterval] ,    [OriginatedInterval] ,    [DisconnectSource],    [CallsConferenced],    [CallsReturnToQ] ,
    [CallsReturnToQDueToTimeout] ,    [IdleTime] 

	from #TempCustomerDetails
	

 WHERE
		--AD.[Timestamp] > @LastProcessedTimestamp
		([OriginatedStamp] > @LastProcessedTimestamp  OR @LastProcessedTimestamp IS NULL)

	
	--select * from #TempCustomerDetails 
	select * from customerCallDetails
	drop table #TempCustomerDetails
	
END;
go

