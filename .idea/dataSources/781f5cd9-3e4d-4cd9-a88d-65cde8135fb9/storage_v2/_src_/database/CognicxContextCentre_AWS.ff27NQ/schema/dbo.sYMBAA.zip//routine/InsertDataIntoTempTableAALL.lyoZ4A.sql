




---select * from AgentActivityDetails
---select * from iAgentPerformanceStat
-- Create a stored procedure

--exec InsertDataIntoTempTable3 @LastProcessedTimestamp='2023-04-04 13:45:00.000'
--exec InsertDataIntoTempTable3 @LastProcessedTimestamp=''
CREATE   PROCEDURE [dbo].[InsertDataIntoTempTableAALL]
@LastProcessedTimestamp DATETIME=NULL
AS
BEGIN


CREATE TABLE #TempAgentActivityDetails (
    
    [TenantID] [int] NULL,
    [Timestamp] [varchar](50) NULL,
    [AgentID] [varchar](50) NULL,
    [AgentSurName] [varchar](255) NULL,
    [AgentGivenName] [varchar](255) NULL,
    [SupervisorLogin] [varchar](50) NULL,
    [SupervisorSurName] [varchar](255) NULL,
    [SupervisorGivenName] [varchar](255) NULL,
    [BreakTime] [varchar](50) NULL,
    [CallsAnswered] [varchar](50) NULL,
    [CallsOffered] [varchar](50) NULL,
    [HoldTime] [varchar](50) NULL,
    [LoggedInTime] [varchar](50) NULL,
    [NotReadyTime] [varchar](50) NULL,
    [RingTime] [varchar](50) NULL,
    [ShortCallsAnswered] [varchar](50) NULL,
    [TalkTime] [varchar](50) NULL,
    [WaitingTime] [varchar](50) NULL,
    [UserID] [varchar](50) NULL,
    [SupervisorUserID] [varchar](50) NULL,
    [Time][varchar](50) NULL,
    [SiteID] [varchar](50) NULL,
    [Site] [varchar](50) NULL,
    [PostCallProcessingTime] [int] NULL
	 
);

    -- Insert data into the temporary table
    INSERT INTO #TempAgentActivityDetails (
	   
        [Timestamp],
		[TenantID],
        [AgentID],
        [AgentSurName],
        [AgentGivenName],
        [SupervisorLogin],
        [SupervisorSurName],
        [SupervisorGivenName],
        [BreakTime],
        [CallsAnswered],
        [CallsOffered],
        [HoldTime],
        [LoggedInTime],
        [NotReadyTime],
        [RingTime],
        [ShortCallsAnswered],
        [TalkTime],
        [WaitingTime],
        [UserID],
        [SupervisorUserID],
        [Time],
        [SiteID],
        [Site],
        [PostCallProcessingTime]
		
    )
    SELECT 
        [Timestamp],'2',
        [AgentLogin] as [AgentID],
        [AgentSurName],
        [AgentGivenName],
        [SupervisorLogin],
        [SupervisorSurName],
        [SupervisorGivenName],
        [BreakTime],
        [CallsAnswered],
        [CallsOffered],
        [HoldTime],
        [LoggedInTime],
        [NotReadyTime],
        [RingTime],
        [ShortCallsAnswered],
        [TalkTime],
        [WaitingTime],
        [UserID],
        [SupervisorUserID],
        [Time],
        [SiteID],
        [Site],
        [PostCallProcessingTime]
		FROM [staging2].[dbo].[iAgentPerformanceStatall]
	
	insert into AgentActivityDetails(
	
        [Timestamp],[TenantID],
        [AgentID],
        [AgentSurName],
        [AgentGivenName],
        [SupervisorLogin],
        [SupervisorSurName],
        [SupervisorGivenName],
        [BreakTime],
        [CallsAnswered],
        [CallsOffered],
        [HoldTime],
        [LoggedInTime],
        [NotReadyTime],
        [RingTime],
        [ShortCallsAnswered],
        [TalkTime],
        [WaitingTime],
        [UserID],
        [SupervisorUserID],
        [Time],
        [SiteID],
        [Site],
        [PostCallProcessingTime]
		
    )
	select

	 [Timestamp],[TenantID],
        [AgentID],
        [AgentSurName],
        [AgentGivenName],
        [SupervisorLogin],
        [SupervisorSurName],
        [SupervisorGivenName],
        [BreakTime],
        [CallsAnswered],
        [CallsOffered],
        [HoldTime],
        [LoggedInTime],
        [NotReadyTime],
        [RingTime],
        [ShortCallsAnswered],
        [TalkTime],
        [WaitingTime],
        [UserID],
        [SupervisorUserID],
        [Time],
        [SiteID],
        [Site],
        [PostCallProcessingTime]
		
		FROM #TempAgentActivityDetails
	 WHERE
		--AD.[Timestamp] > @LastProcessedTimestamp
		( [Timestamp] > @LastProcessedTimestamp  OR @LastProcessedTimestamp IS NULL)
	
	select * from #TempAgentActivityDetails 
	--select * from AgentActivityDetails
	drop table #TempAgentActivityDetails
	
END;

--select * from AgentActivityDetails
go

